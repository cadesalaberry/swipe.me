var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'cadesalaberry',
applicationName: 'api-swipe-me',
appUid: 'g9t6vwPrRKcfBzt3Rk',
orgUid: 'HQzRgN7Myvk1Yg6PWK',
deploymentUid: '073e4445-0d91-474a-880f-d74d767a7c4d',
serviceName: 'api-swipe-me',
shouldLogMeta: true,
disableAwsSpans: false,
disableHttpSpans: false,
stageName: 'finch',
pluginVersion: '3.5.0',
disableFrameworksInstrumentation: false})
const handlerWrapperArgs = { functionName: 'api-swipe-me-finch-app', timeout: 6}
try {
  const userHandler = require('./src/index.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
